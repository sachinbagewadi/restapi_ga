const members = [
    {
        id:1,
        name:'Sachin',
        college:'rvce'
    },
    {
        id:2,
        name:'kiran',
        college:'msr'
    },
    {
        id:3,
        name:'Mahesh',
        college:'kle'
    }
]

module.exports = members