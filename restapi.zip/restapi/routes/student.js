const route = require("color-convert/route")
const express = require('express')
const { parse } = require("path/posix")


const members= require('../models/student')
const router = express.Router()

router.get('/',(req,res) => {
    res.json(members)
})

router.get('/:id', (req,res)=> {
    res.json(members.filter((member) =>  member.id === parseInt(req.params.id)))
})

router.post('/', (req, res)=> {
    const newMember = {
        id:req.body.id,
        name:req.body.name,
        college:req.body.college
    }

    members.push(newMember);
    res.json(members)
})


router.put('/:id', (req,res)=> {
    const updMember = req.body;
    members.forEach(member => {
        if(member.id === parseInt(req.params.id)) {
            member.name = updMember.name ? updMember.name : member.name;
            member.college = updMember.college ? updMember.college : member.college;

            res.json({msg:'data updated', member});
        }
    })
})

router.delete('/:id', (req, res)=> {
    res.json({
        msg:'Student Deleted',
        members: members.filter(member => member.id !== parseInt(req.params.id))
    })
})


module.exports = router;